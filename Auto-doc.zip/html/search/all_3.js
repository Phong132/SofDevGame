var searchData=
[
  ['gamescores',['gameScores',['../classgame_scores.html',1,'']]]
];
