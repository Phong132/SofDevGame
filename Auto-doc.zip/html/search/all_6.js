var searchData=
[
  ['levelmanager',['LevelManager',['../class_level_manager.html',1,'']]],
  ['lifemanager',['LifeManager',['../class_life_manager.html',1,'']]]
];
